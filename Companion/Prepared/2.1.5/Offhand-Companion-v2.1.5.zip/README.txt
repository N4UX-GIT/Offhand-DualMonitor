Offhand Companion 2.1.5 (build 2.1.5.1)
SHA-256: 95811DBB7020A20E2541AE123E69FE80721C83A0FD52D0EE5557DD6D54DCCC2A

Extract to a writable folder and run Offhand.exe. Exit any other Companion
installation through its tray menu first. Portable preferences stay in
%LOCALAPPDATA%\Offhand. No installer or administrator rights are required.

Start WoW in ordinary Windowed mode. Select displays and Mainhand, then click
Span WoW Now. Type /reload in WoW after spanning or changing Mainhand/layout.
Restore Window returns the previous window. Save plan stores settings only.
Install the Offhand add-on separately; 2.1.5 Pre-Release Beta 28 is the paired
release. Existing protocol-1 add-ons remain compatible.

This is the same reviewed EXE submitted as Store package 2.1.500.0. The Store
submission is in certification, with publication after approval. The Store
signs its own package, not this portable EXE. Portable checks GitHub only when
you choose Check for Updates. Quiet daily Store checks apply only to Store
installations. The Companion never downloads/installs updates or restarts itself.

Security: this portable EXE is unsigned. SmartScreen/browser reputation or
antivirus warnings may occur. A local Defender scan found no threats, but this
build has no Microsoft Defender file-review verdict. Verify release SHA-256
checksums. Do not disable antivirus or add exclusions to bypass a detection.
Download only from the official repository or use the signed Microsoft Store:
https://github.com/N4UX-GIT/Offhand-DualMonitor/releases/tag/v2.1.5
https://apps.microsoft.com/detail/9PL4PW84Q90W

World of Warcraft gameplay is not automated. No injection or game-memory reads
are used. Settings and recovery data remain local. Wine is experimental; see
Companion/Linux.md in the tagged source. Full physical mixed-DPI/hotplug/three-
monitor and all-client combat acceptance is not established by automated tests.
See the included LICENSE and tagged source for build and security documentation.