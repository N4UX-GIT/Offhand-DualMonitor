Offhand Companion 2.1.3: CUSTOM WORKSPACE REGIONS PROTOTYPE, unpublished.

Exit any other Companion through its tray menu before testing this build.
This ordinary runtime uses your existing Companion preferences. Preserve your
known-good public installation and configuration for rollback. Nothing in this
build has been published to GitHub or the Microsoft Store.

Graphics-reset recovery is enabled only for Retail and Anniversary directories.
A manual or delayed automatic span must first remain stable to arm it. Restore
Window, Pause Monitor and display edits cancel recovery. Restarting Companion
does not infer a recovery arm from an existing span. Three attempts per five
minutes are allowed; failure or unstable recovery stops automatic retries.
Other clients retain ordinary Span/Restore without graphics-reset recovery.
The graininess resize sequence is disabled. Workspace layout opens a chooser showing the currently saved mode.
Choose one monitor or two monitors to open the corresponding editor. The saved
custom mode is the default keyboard choice. Cancel leaves the plan unchanged.
Save plan changes settings only; Span WoW Now applies it. For one monitor, set occupied width,
workspace width, monitor edge and game side. Reserved pixels remain outside WoW.
Select area on monitor opens a visual overlay. Drag its dividers to resize,
drag the occupied area to snap between monitor edges, or swap the two sides.
Use selection returns to the editor; Save plan commits settings. Escape cancels.
Two-monitor workspace keeps the full game monitor and selects one rectangular
workspace on a second monitor. Move or resize its overlay, or enter its offsets
and dimensions. Unused secondary pixels and physical gaps are clipped. The
preview reports the backing surface, which can include clipped pixels.
Custom regions are manual-only; graphics-reset recovery is not armed for them.
Use Restore Window to return to the ordinary window. Open Workspace layout and
choose Use standard display layout to turn off all custom modes. Review the
suggested screens and confirm. Named workspace profiles stay saved.
Narrow panels may not fit or remain readable; use Mainhand for those panels.
Flexible layout prototype adds an explicit single-display editor with centered,
stacked and one-side presets plus numeric rectangles. Enable its checkbox, review
the preview and Save plan. Span WoW Now and a manual /reload apply the layout.
Use the Offhand addon paired with this Companion build for Flexible Layout.
Its addon manifests declare topology schema 3. Schema 1/2 behavior stays
available. Flexible plans use a version 2 profile store copied from version 1;
the original version 1 store is retained. Disable flexible mode and save to
restore the prior geometry settings before using an older Companion. Restore
Window remains the native recovery action. Automatic apply/reload is disabled.
This prototype is not the complete future grid/freeform editor.
Multiple workspaces opens an experimental editor for one full game monitor and
one or two workspaces on different monitors. Choose Workspace A/B and a primary,
then move or resize each area's visual overlay. Existing one-monitor and
two-monitor custom modes retain schema 1. Multiple workspaces requires the new
addon's declared topology capability and uses schema 2. Missing or ambiguous
selected displays refuse apply. The initial outer-surface budget is 16384 pixels
per axis and four times the game area; this is not a renderer support guarantee.
Multiple workspaces can be disabled even when a required display is missing.
Saved region definitions are retained. Choose connected span displays in the
main window before applying a standard layout. Re-enabling a saved custom plan
still requires every configured display. Inactive area controls are disabled.
Physical three-display, combat and mixed-DPI acceptance remain pending.
Workspace profiles saves named Multiple workspaces plans, with stable identities.
Loading selects settings only. Span WoW Now applies the plan; /reload selects its
matching addon workspace layout. Missing monitors or changed resolutions refuse
loading. Save, update, rename and delete leave launcher/update preferences intact.
Addon Profiles offers independent workspace layout presets. Workspace offers
opt-in routing for Map, Character, Spells, Collections, Achievements and Journal.
Manual moves take precedence; Use routing again explicitly clears those moves.
Themes offers a separate preset per custom region, or global theme inheritance.
The current addon also supports independent image/theme and image-fit preferences
per region, with an optional two-image code-free Background Studio library.
The layout editors have consistent dark fields, readable disabled
actions, display numbering, sticky validation feedback and a visual plan preview.
Workspace B is hidden when unused. Save is disabled while a plan is invalid;
disabling custom mode remains possible after monitor loss. Profile changes are
clearly staged until Save changes, and empty/duplicate actions are disabled.
In the rectangular selection overlay, arrows move 10 pixels, Ctrl+arrows move
one pixel, and Shift+arrows resize (Ctrl+Shift uses one-pixel steps). Enter uses
the selection and Escape cancels it. Overlay edits do not save the plan directly.
Native UI and regression checks do not replace physical mixed-DPI, third-monitor,
hotplug, protected-action/combat or full supported-client acceptance.
After a successful span, Companion notifies the Windows Shell that the actual
WoW window is fullscreen. Restore clears that notification. Shell notification
failure is nonfatal and logged. Global taskbar preferences are unchanged.

After spanning with a loaded character UI, use /reload once. Test initial span,
graphics Apply, repeated recovery, Restore, Pause/Resume, display changes and
cold launch using the source checkout's COMPANION-PRODUCTION-RECOVERY-QA.md.
Forever graphics recovery remains outside this production candidate's scope.